const ioredis = require('ioredis');
const conf = require('./config/server');
/**
 * Timer class to manage timers
 */
class Timer {
    constructor() {
        this.db = new ioredis(conf.REDIS.PORT, conf.REDIS.HOST);
        this.db.send_command('config', ['set', 'notify-keyspace-events', 'Ex'], this.onExpire.bind(this));
        this.handler = () => { }
    }
    async start(game, time, timertype, startTime) {
        let endTime = startTime + (time * 1000);
        game.conf.timer = {
            ns: game.conf.ns,
            time,
            timertype,
            startTime,
            endTime
        };
        await this.db.set('timer-' + game.conf.timer.ns, true, 'ex', game.conf.timer.time);
    }
    async cancel(game) {
        await this.db.del('timer-' + game.conf.timer.ns);
    }
    onExpire(e, r) {
        this.dbsub = new ioredis(conf.REDIS.PORT, conf.REDIS.HOST);

        this.dbsub.subscribe("__keyevent@0__:expired", (key) => {
            this.dbsub.on('message', this.onTimerTimeout.bind(this));
        })
    }
    async onTimerTimeout(c, key) {
        if (key.includes('timer')) {
            let ns = key.split('timer-')[1];
            await this.handler(ns);
        }
    }
}

module.exports = new Timer()