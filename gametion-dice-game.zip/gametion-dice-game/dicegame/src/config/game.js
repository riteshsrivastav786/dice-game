module.exports = {
    GAMES: [
        {
            ns: 'public1',
            name: 'Game 1',
            minPlayers: 4,
            maxPlayers: 4,
            isPrivate: false,
            owner: null,
            code: '',
            turnTime: 30,
            nextGameTime: 5,
            winningScore: 61,
            state: 'waiting'
        },
        {
            ns: 'public2',
            name: 'Game 2',
            minPlayers: 4,
            maxPlayers: 4,
            isPrivate: false,
            owner: null,
            code: '',
            turnTime: 30,
            nextGameTime: 5,
            winningScore: 61,
            state: 'waiting'
        },
        {
            ns: 'public3',
            name: 'Game 3',
            minPlayers: 4,
            maxPlayers: 4,
            isPrivate: false,
            owner: null,
            code: '',
            turnTime: 30,
            nextGameTime: 5,
            winningScore: 61,
            state: 'waiting'
        },
        {
            ns: 'public4',
            name: 'Game 4',
            minPlayers: 4,
            maxPlayers: 4,
            isPrivate: false,
            owner: null,
            code: '',
            turnTime: 30,
            nextGameTime: 5,
            winningScore: 61,
            state: 'waiting'
        }
    ],
    PRIVATE_DEFAULT: {
        ns: 'private',
        name: 'Private Game ',
        minPlayers: 4,
        maxPlayers: 4,
        isPrivate: true,
        owner: null,
        code: 'GAMETION50',
        turnTime: 30,
        nextGameTime: 5,
        winningScore: 61,
        state: 'waiting'
    }
}