module.exports = {
    PORT: 3000,
    REDIS: {
        HOST:'localhost',
        PORT: 6379
    }
}