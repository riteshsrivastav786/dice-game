const ioredis = require('ioredis');
const gameConf = require('../config/game')
const conf = require('../config/server');
//  Redis db Data manager
class Database {
    constructor() {
        this.db = new ioredis(conf.REDIS.PORT, conf.REDIS.HOST)
    }
    removeAllGames() {
        return this.db.del('games');
    }
    addAllGames() {
        let games = {};
        gameConf.GAMES.map((game) => {
            games[game.ns] = JSON.stringify(game);
        })
        return this.db.hset('games', games);
    }
    async getAllTables(token) {
        let publics = [];
        let privates = [];
        let games = await this.db.hgetall('games');
        for (const key in games) {
            if (Object.hasOwnProperty.call(games, key)) {
                const game = JSON.parse(games[key]);
                if(game.isPrivate){
                    if(game.owner == token|| (game.players && game.players[token]))
                    privates.push(game);
                } else {
                    publics.push(game);
                }
            }
        }
        return { public: publics, private: privates };
    }
    async getAllTablesNameSpace (){
        return Object.keys(await this.db.hgetall('games'));
    }
    saveUser(username, token) {
        this.db.set(token, JSON.stringify({ username, token }));
    }
    async getUserByToken(token) {
        let user = await this.db.get(token);
        return JSON.parse(user);
    }
    async getGame(ns) {
        let game = await this.db.hget('games', ns);
        if (game) {
            return JSON.parse(game);
        }
        return null;
    }
    async getGameByCode(code) {
        let games = await this.db.hgetall('games');
        for (const key in games) {
            if (Object.hasOwnProperty.call(games, key)) {
                const game = JSON.parse(games[key]);
                if(game.code == code){
                    return game;
                }
            }
        }
        return null;
    }
    async updateGame(game) {
        return await this.db.hset('games', game.conf.ns, JSON.stringify(game.conf))
    }
    async getGamesCount(){
        return (await this.getAllTablesNameSpace()).length;
    }
}
module.exports = new Database();