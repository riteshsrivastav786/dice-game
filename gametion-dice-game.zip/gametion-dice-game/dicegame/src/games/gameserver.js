const Lobby = require('./lobby');
const gameManager = require('./game-manager');
// class to bootstrap  game server
class GameServer {
    constructor(io){
        this.io = io
    }
    async init(){
        this.lobby = new Lobby('/lobby', this.io);
        await gameManager.init();
        await gameManager.createNameSpaceForAllGames(this.io)
    }
}
module.exports = GameServer