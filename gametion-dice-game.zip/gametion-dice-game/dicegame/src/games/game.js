const { Emitter } = require('@socket.io/redis-emitter');
const ioredis = require('ioredis');
const timer = require("../timer");
const db = require('../db/redis');
const server = require("../config/server");
const game = require('../config/game');
// Game class to take action as per game rule
class Game {
    constructor(conf) {
        this.conf = conf;
        this.conf.history = this.conf.history || [];
        this.emitter = new Emitter(new ioredis(server.REDIS.PORT, server.REDIS.HOST), {}, '/' + this.conf.ns);
    }
    sendToAll(msg) {
        this.emitter.emit('request', msg)
    }
    async addPlayer(player) {
        this.conf.players = this.conf.players || {};
        if (this.conf.players[player.token]) {
            return 0;
        }
        if (Object.keys(this.conf.players).length >= this.conf.maxPlayers) {
            return 2;
        }
        if (this.conf.state == 'running') {
            return 1;
        }
        this.conf.players[player.token] = player;
        this.conf.history.push({ type: 'info', 'message': `${player.username} joined game` })
        if (Object.keys(this.conf.players).length == this.conf.minPlayers) {
            this.conf.history.push({ type: 'alert', 'message': `Starting next game in ${this.conf.nextGameTime}` })
            await timer.start(this, this.conf.nextGameTime, 'start_game_timer', new Date().valueOf());
        }
        return 0;
    }
    async onTimerEnd() {
        if (this.conf.timer) {
            switch (this.conf.timer.timertype) {
                case 'start_game_timer':
                    return await this.startNewGame();
                case 'turn_timer':
                    return await this.skipTurn(true);
            }
        }
    }
    async startNewGame() {
        this.conf.historyId = this.conf.historyId || 0;
        this.conf.historyId += 1;
        this.conf.history = [];
        let leftPlayers = [];
        for (const key in this.conf.players) {
            if (Object.hasOwnProperty.call(this.conf.players, key)) {
                const player = this.conf.players[key];
               if(player.left == true){
                leftPlayers.push(key)
                this.conf.history.push({ type: 'info', 'message': `${player.username} leaved game` })
               }
            }
        }
        for (const token of leftPlayers) {
            delete this.conf.players[token];
        }
        for (const key in this.conf.players) {
            if (Object.hasOwnProperty.call(this.conf.players, key)) {
                const player = this.conf.players[key];
                player.score = 0;
                player.disconnected = true;
                this.conf.history.push({ type: 'info', 'message': `${player.username} joined game` })
            }
        }
        if(Object.keys(this.conf.players).length < this.conf.minPlayers){
            this.conf.state = 'waiting';
        this.conf.history.push({ type: 'info', 'message': `waiting for more players to join` })
        this.sendToAll({ type: 'initAction', data: this.conf })
            await db.updateGame(this);
            return;
        }
        this.conf.state = 'running';
        this.conf.history.push({ type: 'info', 'message': `starting game #${this.conf.historyId}` })
        this.conf.currentTurnIndex = 0;
        await timer.start(this, this.conf.turnTime, 'turn_timer', new Date().valueOf());
        this.sendTurnInfo();
        this.sendToAll({ type: 'initAction', data: this.conf })
        await db.updateGame(this);
    }
    async makeMove(token){
        let player = this.getCurrentPlayer();
        if(player.token != token){
            return false;
        }
        await timer.cancel(this);
        this.skipTurn(false).then();
        return true;
    }
    async leaveGame(token){
        let player = this.getPlayerByToken(token);
        if(!player ||  player.token != token){
            return false;
        }
        player.left = true;
        if(this.conf.state == 'waiting'){
            delete this.conf.players[token];
        }
        this.sendToAll({ type: 'initAction', data: this.conf })
        await db.updateGame(this);
        return true;
    }
    async skipTurn(auto) {
        let score = this.playDice();
        let player = this.getCurrentPlayer();
        this.conf.history.push({ type: auto?'auto':'action', 'message': `${player.username} ${auto?'turn auto run':' taked action and '} got : ${score}` })
        if(player.score >= this.conf.winningScore){
            this.conf.history.push({ type: 'alert', 'message': `${player.username} win the game` })
            this.conf.history.push({ type: 'alert', 'message': `Starting next game in ${this.conf.nextGameTime}` })
            await timer.start(this, this.conf.nextGameTime, 'start_game_timer', new Date().valueOf());
            this.conf.currentTurnIndex = -10;
            this.conf.currentTurn = null
        } else {
            await this.changeTurn();
        }
        this.sendToAll({ type: 'initAction', data: this.conf })
        await db.updateGame(this);
    }
    async changeTurn(){
        this.conf.currentTurnIndex += 1;
        if (this.conf.currentTurnIndex >= Object.keys(this.conf.players).length) {
            this.conf.currentTurnIndex = 0;
        }
        console.log('turnskip', this.conf.currentTurnIndex)
        await timer.start(this, this.conf.turnTime, 'turn_timer', new Date().valueOf());
        this.sendTurnInfo();
    }
    sendTurnInfo() {
        this.conf.currentTurn = Object.keys(this.conf.players)[this.conf.currentTurnIndex];
        let player = this.getCurrentPlayer();
        this.conf.history.push({ type: 'info', 'message': `${player.username}'s turn now` })
        this.sendToAll({
            type: 'turnInfo',
            data: {
                timer: this.conf.timer,
                player: this.conf.players[Object.keys(this.conf.players)[this.conf.currentTurnIndex]]
            }
        })
    }
    playDice() {
        let renNum = this.rendomNomber(1, 6);
        let player = this.getCurrentPlayer();
        player.score += renNum;
        return renNum;
    }
    rendomNomber(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min)
    }
    getCurrentPlayer(){
        return this.conf.players[Object.keys(this.conf.players)[this.conf.currentTurnIndex]];
    }
    getPlayerByToken(token){
        return this.conf.players[token];
    }
}

module.exports = Game;