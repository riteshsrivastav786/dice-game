const Namespace = require('./namespace');
const db = require('../db/redis');
const gameManager = require('./game-manager');
const {Emitter} = require('@socket.io/redis-emitter');
const ioredis = require('ioredis');
const server = require('../config/server');
const gameConf = require('../config/game');
/**
 * Lobby class to  mange lobby for the users
 */
class Lobby {
    constructor(id, io) {
        this.channel = new Namespace(id, io, this);
        this.emitter = new Emitter(new ioredis(server.REDIS.PORT,server.REDIS.HOST),{},id);
    }
    sendToAll(msg) {
        this.emitter.emit('request', msg)
    }
    async getProfile(req) {
        return { type: 'getProfile', data: await db.getUserByToken(req.token) };
    }
    async getTables(req) {
        return { type: 'getTables', data: await db.getAllTables(req.token) };
    }
    async joinTable(req) {
        let player = await db.getUserByToken(req.token);
        let game = null;
        try {
            game = await gameManager.getGame(req.ns);
        } catch (error) {
            console.log(error)
            return { type: 'error', error: 'game not found' };
        }
        switch (await game.addPlayer(player)) {
            case 2:
                return { type: 'error', error: 'table already full' };
            case 1:
                return { type: 'error', error: 'table already running' };
        }
        await db.updateGame(game);
        game.sendToAll({ type: 'initAction', data: game.conf });
        this.sendToAll({ type: 'tableUpdate', data: game.conf });
        return { type: 'joinTable', data: { ns: req.ns } };
    }
    async joinPrivate(req) {
        let player = await db.getUserByToken(req.token);
        let game = null;
        try {
            game = await gameManager.getGameByCode(req.code);
        } catch (error) {
            console.log(error)
            return { type: 'error', error: 'game not found' };
        }
        switch (await game.addPlayer(player)) {
            case 2:
                return { type: 'error', error: 'table already full' };
            case 1:
                return { type: 'error', error: 'table already running' };
        }
        await db.updateGame(game);
        game.sendToAll({ type: 'initAction', data: game.conf });
        this.sendToAll({ type: 'tableUpdate', data: game.conf });
        return { type: 'joinPrivate', data: { ns: game.conf.ns } };
    }
    async addPrivateTable(req) {
        let game = JSON.parse(JSON.stringify(gameConf.PRIVATE_DEFAULT));
        let count = await db.getGamesCount();
        game.code += count;
        game.owner = req.token;
        game.ns += count;
        game.name += count;
        await db.updateGame({conf:game});
        await gameManager.createNameSpaceForGame(game.ns);
        this.sendToAll({ type: 'tablerefresh', data: true});
        return { type: 'addPrivateTable', data: game };
    }
}
module.exports = Lobby;