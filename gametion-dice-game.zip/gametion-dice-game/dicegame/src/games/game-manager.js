const db = require('../db/redis');
const Game = require('./game');
const timer = require('../timer');
const Namespace = require('./namespace');
// Game manager to mange game and work as a game service
class GameManager {
    constructor(){
        timer.handler = this.onTimerEnd.bind(this);
    }
    async init (){
        await this.clearGames();
        await this.addGames();
    }
    async clearGames(){
        console.log('cleaning games');
        await db.removeAllGames();
    }
    async addGames(){
        console.log('adding games');
        await db.addAllGames();
    }
    async getGame(ns){
        let game  =  await db.getGame(ns);
        return new Game(game);
    }
    async getGameByCode(code){
        let game  =  await db.getGameByCode(code);
        return new Game(game);
    }
    async onTimerEnd(ns){
        let game = await this.getGame(ns);
        await game.onTimerEnd();
    }
    async createNameSpaceForAllGames(io){
        this.io = this.io||io;
        let tables = await db.getAllTablesNameSpace();
        for (const ns of tables) {
            new Namespace('/'+ns, this.io, this);
        }
    }
    async createNameSpaceForGame(ns){
        new Namespace('/'+ns, this.io, this);
    }
    async initAction(req, ns) {
        let  game  = await this.getGame(ns.replace('/',''));
        return { type: 'initAction', data: game.conf };
    }
    async makeMove(req, ns) {
        let  game  = await this.getGame(ns.replace('/',''));
        return { type: 'makeMove', data: await game.makeMove(req.token) };
    }
    async leaveGame(req, ns) {
        let  game  = await this.getGame(ns.replace('/',''));
        return { type: 'leveGame', data: await game.leaveGame(req.token) };
    }
    async getProfile(req) {
        return { type: 'getProfile', data: await db.getUserByToken(req.token) };
    }
}
module.exports = new GameManager();